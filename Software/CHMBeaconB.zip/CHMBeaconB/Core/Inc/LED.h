#ifndef INC_LED_H_
#define INC_LED_H_
/**
 * LED Driver: PCA9685PW (I²C Communication Protocol)
 */
#define LED_ADDRESS 0x40 // LED Module Address (I²C Bus)

/**
 * LED States (ON is ALWAYS set to 1)
 */
#define LED_STATE_0 0b00000000
#define LED_STATE_1 0b00010000

/**
 * Blue LEDs (Registers)
 */
// LED8 (Registers)
#define LED8_ON_L_REGISTER 0x26
#define LED8_ON_H_REGISTER 0x27
#define LED8_OFF_L_REGISTER 0x28
#define LED8_OFF_H_REGISTER 0x29
// LED10 (Registers)
#define LED10_ON_L_REGISTER 0x2E
#define LED10_ON_H_REGISTER 0x2F
#define LED10_OFF_L_REGISTER 0x30
#define LED10_OFF_H_REGISTER 0x31
// LED12 (Registers)
#define LED12_ON_L_REGISTER 0x36
#define LED12_ON_H_REGISTER 0x37
#define LED12_OFF_L_REGISTER 0x38
#define LED12_OFF_H_REGISTER 0x39
// LED14 (Registers)
#define LED14_ON_L_REGISTER 0x3E
#define LED14_ON_H_REGISTER 0x3F
#define LED14_OFF_L_REGISTER 0x40
#define LED14_OFF_H_REGISTER 0x41

/**
 * RGB LED (Registers)
 */
// LED1 (Register)
#define LED1_ON_L_REGISTER 0x0A
#define LED1_ON_H_REGISTER 0x0B
#define LED1_OFF_L_REGISTER 0x0C
#define LED1_OFF_H_REGISTER 0x0D
// LED2 (Register)
#define LED2_ON_L_REGISTER 0x0E
#define LED2_ON_H_REGISTER 0x0F
#define LED2_OFF_L_REGISTER 0x10
#define LED2_OFF_H_REGISTER 0x11

/**
 * LED Controls (Functions)
 */
void LED_Init(void);
void LED_Write(uint8_t, uint8_t);

/**
 * Blue LEDs (Functions)
 */
// Blue LED 1 (Pin: LED8)
void Blue_LED1_ON(void);
void Blue_LED1_OFF(void);
// Blue LED 2 (Pin: LED10)
void Blue_LED2_ON(void);
void Blue_LED2_OFF(void);
// Blue LED 3 (Pin: LED12)
void Blue_LED3_ON(void);
void Blue_LED3_OFF(void);
// Blue LED 4 (Pin: LED14)
void Blue_LED4_ON(void);
void Blue_LED4_OFF(void);

/**
 * RGB LED (Functions)
 */
void RGB_LED_ON(void);
void RGB_LED_OFF(void);

#endif /* INC_LED_H_ */
