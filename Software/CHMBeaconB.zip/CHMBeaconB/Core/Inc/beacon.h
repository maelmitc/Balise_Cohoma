#ifndef INC_BEACON_H_
#define INC_BEACON_H_

#define BATTERY_FULL_CHARGE_LEVEL 500 // Ah

enum ChargeState {
	CHARGE,
	DISCHARGE,
	UNDEFINED
};

struct beacon {
	enum ChargeState charge_state;
	float battery_charge_level;
	float ping;
};

typedef struct beacon BEACON;

BEACON set_up_beacon(void);

float update_battery_state_of_charge(BEACON beacon, int SOC1, int v, int current, int interval);

void update_battery_charge_level(float);

#endif /* INC_BEACON_H_ */
