#include "beacon.h"
#include "LED.h"

BEACON set_up_beacon(void) {
	BEACON beacon = calloc(1, sizeof(BEACON));
	beacon.charge_state = UNDEFINED;
	beacon.battery_charge_level = 0;
	beacon.ping = 0;
}

float update_battery_state_of_charge(BEACON beacon, int SOC1, int v, int current, int interval) {
	// State of Charge Algorithm
	float charge = current*interval;
	float SOC2 = SOC1-(current/BATTERY_CELL_CAPACITY)*interval;

	if (SOC2 < SOC1) {
		beacon.charge_state = DISCHARGE;
	} else {
		beacon.charge_state = CHARGE;
	}

	return SOC2;
}

void update_battery_charge_level(float SOC) {
	float level = SOC/100*BATTERY_FULL_CHARGE_LEVEL;
	if (level > 0.75) {
		Blue_LED1_ON();
		Blue_LED2_ON();
		Blue_LED3_ON();
		Blue_LED4_ON();
	} else if (level > 0.5) {
		Blue_LED1_ON();
		Blue_LED2_ON();
		Blue_LED3_ON();
		Blue_LED4_OFF();
	} else if (level > 0.25) {
		Blue_LED1_ON();
		Blue_LED2_ON();
		Blue_LED3_OFF();
		Blue_LED4_OFF();
	} else if (level > 0.05) {
		Blue_LED1_ON();
		Blue_LED2_OFF();
		Blue_LED3_OFF();
		Blue_LED4_OFF();
	} else {
		Blue_LED1_OFF();
		Blue_LED2_OFF();
		Blue_LED3_OFF();
		Blue_LED4_OFF();
	}
}
