#include "LED.h"
/**
 * LED Controls
 */
void LED_Write(uint8_t LED_register_H, uint8_t write) {
	uint8_t LED_Buffer[2];

	LED_Buffer[0] = LED_register_H;
	LED_Buffer[1] = write;

	if (HAL_I2C_Master_Transmit_IT(&hi2c1, LED_ADDRESS, LED_Buffer, sizeof(LED_Buffer)) != HAL_OK) {
		Error_Handler();
	}
}

// ON is ALWAYS set to 1, only OFF change (1: LED is OFF, 0: LED is ON)
void LED_Init() {
	// Blue LEDs
	LED_Write(LED8_ON_H_REGISTER, LED_STATE_1);
	LED_Write(LED10_ON_H_REGISTER, LED_STATE_1);
	LED_Write(LED12_ON_H_REGISTER, LED_STATE_1);
	LED_Write(LED14_ON_H_REGISTER, LED_STATE_1);
	// RGB LED
	LED_Write(LED1_ON_H_REGISTER, LED_STATE_1);
	LED_Write(LED2_ON_H_REGISTER, LED_STATE_1);
}

/**
 * Blue LEDs
 */
// Blue LED 1
void Blue_LED1_ON() {
	LED_Write(LED8_OFF_H_REGISTER, LED_STATE_0);
}

void Blue_LED1_OFF() {
	LED_Write(LED8_OFF_H_REGISTER, LED_STATE_1);
}

// Blue LED 2
void Blue_LED2_ON() {
	LED_Write(LED10_OFF_H_REGISTER, LED_STATE_0);
}

void Blue_LED2_OFF() {
	LED_Write(LED10_OFF_H_REGISTER, LED_STATE_1);
}

// Blue LED 3
void Blue_LED3_ON() {
	LED_Write(LED12_OFF_H_REGISTER, LED_STATE_0);
}

void Blue_LED3_OFF() {
	LED_Write(LED12_OFF_H_REGISTER, LED_STATE_1);
}

// Blue LED 4
void Blue_LED4_ON() {
	LED_Write(LED14_OFF_H_REGISTER, LED_STATE_0);
}

void Blue_LED4_OFF() {
	LED_Write(LED14_OFF_H_REGISTER, LED_STATE_1);
}

/*
 * RGB LED
 */
void RGB_LED_ON() {
	LED_Write(LED1_OFF_H_REGISTER, LED_STATE_0);
	LED_Write(LED2_OFF_H_REGISTER, LED_STATE_0);
}

void RGB_LED_OFF() {
	LED_Write(LED1_OFF_H_REGISTER, LED_STATE_1);
	LED_Write(LED2_OFF_H_REGISTER, LED_STATE_1);
}
